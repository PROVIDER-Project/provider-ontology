# PROVIDER Ontologie-Review 13.10.2026

Zuerst reports/ontology-review/2026-10-13/PROVIDER_Ontologie_Review.pdf öffnen.
Aktuelles Modell: ontology/current/provider.ttl mit lokalem catalog-v001.xml.
Für die Offline-Prüfung Python-Umgebung aus requirements-validation.txt verwenden und aus dem Paketroot ausführen:

python tools/review_current.py --data examples/current/ap2-example.ttl --output output/review.json

Das Paket enthält den aktuellen Modellkandidaten, Kompetenzfragen, synthetische Beispiele und datierte Nachweise. Es enthält keine vollständigen echten Comext-Daten und nicht alle historischen Repositorydateien. Für historische Tests und die vollständige Git-Belegkette den Checkout verwenden. Keine öffentliche Datenfreigabe, keine Produktionsumschaltung und keine Partnerabnahme. Modullizenzen und Quelldatenbedingungen bleiben getrennt; insbesondere behält das Eventmodul seine CC-BY-4.0-Angabe.
