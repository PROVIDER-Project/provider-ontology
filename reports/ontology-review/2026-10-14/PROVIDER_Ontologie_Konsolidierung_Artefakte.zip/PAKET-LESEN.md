# PROVIDER – Ontologie-Konsolidierung 14.10.2026

Bericht: reports/ontology-review/2026-10-14/PROVIDER_Ontologie_Konsolidierung.pdf.
Details: docs/ontology-consolidation.md; Fachprofile: docs/model-profiles.md.

Mit Python-Umgebung aus requirements-validation.txt ist die lokale Modellprüfung ohne Netzwerkimporte ausführbar:
python tools/review_current.py --data examples/current/ap2-example.ttl --output output/review.json

Die Java-Logikprüfung benötigt das separat hashgeprüfte ROBOT-JAR (tools/fetch_reasoner.py); BFO2020-Kern ist enthalten. Vollständige Repository-Regressionen benötigen den Checkout, zusätzliche Echtdatenpiloten die in der Dokumentation beschriebenen echten Inputs und provider-datasets. Dieses Paket enthält keine vollständigen echten Daten. Frühere rc1-Dateien sind als Vorgängerstand beigefügt. Lizenzen und Quellenbedingungen bleiben getrennt. Lokaler Kandidat, keine Veröffentlichung oder Partnerabnahme.
